### 简介
这是一个基于高德SDK的Android导航项目

### 主要功能截图
![ljnavigation_01](https://raw.githubusercontent.com/djstava/PostsCollection/master/images/android/ljnavigation/ljnavigation_01.png)

![ljnavigation_02](https://raw.githubusercontent.com/djstava/PostsCollection/master/images/android/ljnavigation/ljnavigation_02.png)

![ljnavigation_03](https://raw.githubusercontent.com/djstava/PostsCollection/master/images/android/ljnavigation/ljnavigation_03.png)

![ljnavigation_04](https://raw.githubusercontent.com/djstava/PostsCollection/master/images/android/ljnavigation/ljnavigation_04.png)

![ljnavigation_05](https://raw.githubusercontent.com/djstava/PostsCollection/master/images/android/ljnavigation/ljnavigation_05.png)

![ljnavigation_06](https://raw.githubusercontent.com/djstava/PostsCollection/master/images/android/ljnavigation/ljnavigation_06.png)

![ljnavigation_07](https://raw.githubusercontent.com/djstava/PostsCollection/master/images/android/ljnavigation/ljnavigation_07.png)

![ljnavigation_08](https://raw.githubusercontent.com/djstava/PostsCollection/master/images/android/ljnavigation/ljnavigation_08.png)


